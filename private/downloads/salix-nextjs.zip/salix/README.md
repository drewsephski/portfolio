# salix Next.js template

Run `pnpm install`, then `pnpm dev`. This package contains the route source and its local assets. Replace the sample brand, copy, and links before publishing.
